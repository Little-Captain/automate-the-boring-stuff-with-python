#!/usr/bin/env python

# 用 zipfile 模块压缩文件
# 利用 zipfile 模块中的函数，Python 程序可以创建和打开（或解压）ZIP 文件
